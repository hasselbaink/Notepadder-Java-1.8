package com.neeq.frames;
/**
 * This class is a main frame in this program
 * @author hasselbaink
 * @version 1.0
 * @since 1.0
 */
import java.awt.Component;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JPanel;
//import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import com.neeq.design.*;
import com.neeq.tools.*;

public class MainFrame{
	private GUI gui;
	private Borders border		= new Borders();
	private Colors color		= new Colors();
	private Fonts font		= new Fonts();
	
	private FileWorker fileWorker;
	private TextCorrecter textCorrecter = new TextCorrecter();
	
	private JPanel mainPanel;
	private JButton createFile, openFile;
	private JFileChooser fileChooser = new JFileChooser();
	
	//private JLabel recentFilesLabel;
	
	public MainFrame(){
		gui.name = "Notepadder [HTML]";
		gui.layout = null;
		gui.w = 640;
		gui.h = 480;
		gui.resizable = false;
		gui.clsOpr = gui.EXIT_ON_CLOSE;
		initComp();
		gui = new GUI();
		gui.add(mainPanel);
	}
	/** This method initialize our gui components */
	private void initComp(){
		mainPanel = new JPanel();
		mainPanel.setSize(640, 480);
		mainPanel.setLocation(0, 0);
		mainPanel.setLayout(null);
		mainPanel.setBackground(color.WHITE);
		
			createFile = new JButton("Create File");
			createFile.setSize(100, 30);
			createFile.setLocation(20, 20);
			createFile.setFont(font.COLIBRI16);
			createFile.setForeground(color.BLACK);
			createFile.setBackground(color.WHITE);
			createFile.setBorder(border.EMPTY);
			createFile.setFocusable(false);
			createFile.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
					CreateFileFrame createFileFrm = new CreateFileFrame(); 
				}
			});
			addComp(createFile);
			
			openFile = new JButton("Open File");
			openFile.setSize(100, 30);
			openFile.setLocation(20, 50);
			openFile.setFont(font.COLIBRI16);
			openFile.setForeground(color.BLACK);
			openFile.setBackground(color.WHITE);
			openFile.setBorder(border.EMPTY);
			openFile.setFocusable(false);
			openFile.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
					fileChooser.setFileSelectionMode(0);
					fileChooser.showOpenDialog(null);
					EditorFrame editorFrame = new EditorFrame(fileChooser.getSelectedFile());
				}
			});
			addComp(openFile);
			
			/*
			recentFilesLabel = new JLabel("Recent Files:");
			recentFilesLabel.setSize(100, 30);
			recentFilesLabel.setLocation(150, 20);
			recentFilesLabel.setFont(font.COLIBRI16BOLD);
			recentFilesLabel.setForeground(color.BLACK);
			addComp(recentFilesLabel);
			*/
			
			/*fileWorker = new FileWorker("res//recentFiles.txt");
			if(!fileWorker.hasFile()) fileWorker.createFile();
			else
			{
				String[] list = textCorrecter.correctRecentFilesNames(fileWorker.readFile());
				for(String s : list)
					System.out.println(s);
			}*/
		mainPanel.updateUI();
	}
	/**
	 * This method add components in our main panel.
	 * @param Component GUI component, which we want add in our main panel
	 */
	private void addComp(Component comp){
		mainPanel.add(comp);
	}
}
