package com.neeq.frames;
/**
 * This class is a frame where we set a name and path for our file
 * @author hasselbaink
 * @version 1.0
 * @since 1.0
 */
import java.awt.Component;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JFileChooser;
import javax.swing.JComboBox;
import javax.swing.JButton;

import com.neeq.design.*;
import com.neeq.tools.*;

public class CreateFileFrame{
	private GUI gui;
	private Borders border		= new Borders();
	private Colors color		= new Colors();
	private Fonts font		= new Fonts();
	
	private TextCorrecter textCorrecter = new TextCorrecter();
	
	private JPanel mainPanel;
	
	private JLabel fileNameLabel;
	private JTextField fileNameField;
	private JComboBox fileNameTypeBox;
	
	private JLabel filePathLabel;
	private JTextField filePathField;
	private JButton filePathDetectButton;
	
	private JButton createFileButton;
	public CreateFileFrame(){
		gui.name = "Create New File";
		gui.layout = null;
		gui.w = 400;
		gui.h = 500;
		gui.clsOpr = gui.DISPOSE_ON_CLOSE;
		initComp();
		gui = new GUI();
	}
	/** This method initialize our gui components */
	private void initComp(){
		mainPanel = new JPanel();
		mainPanel.setSize(400, 500);
		mainPanel.setLocation(0, 0);
		mainPanel.setLayout(null);
		mainPanel.setBackground(color.WHITE);
		
			fileNameLabel = new JLabel("File Name:");
			fileNameLabel.setSize(100, 20);
			fileNameLabel.setLocation(10, 10);
			fileNameLabel.setFont(font.COLIBRI16);
			fileNameLabel.setForeground(color.BLACK);
			addComp(fileNameLabel);
			
			fileNameField = new JTextField();
			fileNameField.setSize(300, 30);
			fileNameField.setLocation(10, 35);
			fileNameField.setFont(font.COLIBRI16);
			fileNameField.setForeground(color.BLACK);
			fileNameField.setBackground(color.C230);
			fileNameField.setBorder(border.EMPTY1616);
			addComp(fileNameField);
			
			fileNameTypeBox = new JComboBox(FileWorker.fileTypesString);
			fileNameTypeBox.setSize(60, 30);
			fileNameTypeBox.setLocation(320, 35);
			fileNameTypeBox.setFont(font.COLIBRI16);
			fileNameTypeBox.setForeground(color.BLACK);
			fileNameTypeBox.setBackground(color.C230);
			fileNameTypeBox.setBorder(border.EMPTY);
			addComp(fileNameTypeBox);
			
			filePathLabel = new JLabel("Path:");
			filePathLabel.setSize(50, 20);
			filePathLabel.setLocation(10, 80);
			filePathLabel.setFont(font.COLIBRI16);
			filePathLabel.setForeground(color.BLACK);
			addComp(filePathLabel);
			
			filePathField = new JTextField();
			filePathField.setSize(300, 30);
			filePathField.setLocation(10, 105);
			filePathField.setFont(font.COLIBRI16);
			filePathField.setForeground(color.BLACK);
			filePathField.setBackground(color.C230);
			filePathField.setBorder(border.EMPTY1616);
			addComp(filePathField);
			
			filePathDetectButton = new JButton("...");
			filePathDetectButton.setSize(60, 30);
			filePathDetectButton.setLocation(320, 105);
			filePathDetectButton.setFont(font.COLIBRI16);
			filePathDetectButton.setForeground(color.BLACK);
			filePathDetectButton.setBackground(color.LIGHT_GRAY);
			filePathDetectButton.setBorder(border.EMPTY);
			filePathDetectButton.setFocusable(false);
			filePathDetectButton.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
					JFileChooser fileChooser = new JFileChooser();
					fileChooser.showSaveDialog(null);
					fileNameField.setText(textCorrecter.correctFileName(
							fileChooser.getSelectedFile().getName(), 
							FileWorker.fileTypesString));
					filePathField.setText(fileChooser.getSelectedFile().getParent());
				}
			});
			addComp(filePathDetectButton);
			
			createFileButton = new JButton("Create File");
			createFileButton.setSize(100, 30);
			createFileButton.setLocation(280, 170);
			createFileButton.setFont(font.COLIBRI16);
			createFileButton.setForeground(color.BLACK);
			createFileButton.setBackground(color.C220);
			createFileButton.setBorder(border.EMPTY);
			createFileButton.setFocusable(false);
			createFileButton.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
					String path = 
							filePathField.getText() + "//" +
							fileNameField.getText() +
							(String)fileNameTypeBox.getSelectedItem();
					FileWorker fileWorker = new FileWorker(path);
					fileWorker.createFile();
					gui.dispose();
					EditorFrame editorFrame = new EditorFrame(fileWorker.getPath());
				}
			});
			addComp(createFileButton);
	}
	/**
	 * This method add components in our main panel.
	 * @param Component GUI component, which we want add in our main panel
	 */
	private void addComp(Component comp){
		gui.add(comp);
	}
}
