package com.neeq.frames;
/**
 * This class is a editor frame in this program
 * @author hasselbaink
 * @version 1.0
 * @since 1.0
 */
import java.io.File;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JButton;

import com.neeq.design.Borders;
import com.neeq.design.Colors;
import com.neeq.design.Fonts;
import com.neeq.tools.*;

public class EditorFrame{
	private GUI gui;
	private Borders border		= new Borders();
	private Colors color		= new Colors();
	private Fonts font		= new Fonts();
	
	private File path;
	private String fileName = "";
	
	private FileWorker fileWorker;
	//private TextCorrecter textCorrecter = new TextCorrecter();
	
	private JPanel mainPanel;
	
	private JPanel toolsPanel;
	private JLabel fileNameLabel;
	private JButton fileSaveButton;
	
	private JScrollPane scrollPane;
	private JTextArea textArea;
	
	public EditorFrame(File path){
		this.path = path;
		fileWorker	= new FileWorker(this.path);
		fileName = this.path.getName();
		
		gui.name = "Notepadder [HTML] [" + this.fileName + "]";
		gui.layout = null;
		gui.w = 640;
		gui.h = 480;
		gui.resizable = false;
		gui.clsOpr = gui.DISPOSE_ON_CLOSE;
		initComp();
		gui = new GUI();
		gui.add(mainPanel);
	}
	/** This method initialize our gui components */
	private void initComp(){
		mainPanel = new JPanel();
		mainPanel.setSize(640, 480);
		mainPanel.setLocation(0, 0);
		mainPanel.setLayout(null);
		mainPanel.setBackground(color.WHITE);
		
			toolsPanel = new JPanel();
			toolsPanel.setSize(640, 40);
			toolsPanel.setLocation(0, 0);
			toolsPanel.setLayout(null);
			toolsPanel.setBackground(color.C230);
			
				fileNameLabel = new JLabel(this.fileName);
				fileNameLabel.setSize(200, 30);
				fileNameLabel.setLocation(10, 5);
				fileNameLabel.setFont(font.COLIBRI16);
				fileNameLabel.setForeground(color.C70);
				
				fileSaveButton = new JButton("Save");
				fileSaveButton.setSize(70, 30);
				fileSaveButton.setLocation(550, 5);
				fileSaveButton.setFont(font.COLIBRI16BOLD);
				fileSaveButton.setForeground(color.C100);
				fileSaveButton.setBackground(color.C230);
				fileSaveButton.setBorder(border.EMPTY);
				fileSaveButton.setFocusable(false);
				fileSaveButton.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e){
						fileWorker.saveFile(textArea.getText());
					}
				});
			
			toolsPanel.add(fileNameLabel);
			toolsPanel.add(fileSaveButton);
			
			scrollPane = new JScrollPane();
			scrollPane.setSize(640, 400);
			scrollPane.setLocation(0, 40);
			scrollPane.setBackground(color.WHITE);
			scrollPane.setBorder(border.EMPTY);
			
				textArea = new JTextArea(fileWorker.readFile());
				textArea.setSize(new Dimension(640, 400));
				textArea.setLocation(0, 0);
				textArea.setFont(font.COLIBRI16BOLD);
				textArea.setForeground(color.BLACK);
				textArea.setBackground(color.WHITE);
				textArea.setBorder(border.EMPTY6666);
				
			scrollPane.setViewportView(textArea);
			
		mainPanel.add(toolsPanel);
		mainPanel.add(scrollPane);
			
	}
	/**
	 * This method add components in our main panel.
	 * @param Component GUI component, which we want add in our main panel
	 */
	private void addComp(Component comp){
		mainPanel.add(comp);
	}
}
