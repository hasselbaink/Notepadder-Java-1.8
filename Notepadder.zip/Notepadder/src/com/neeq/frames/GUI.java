package com.neeq.frames;
/**
 * This class is a gui template for creating frame on swing framework
 * @author hasselbaink
 * @version 1.0
 * @since 1.0
 */
import java.awt.LayoutManager;
import javax.swing.JFrame;

class GUI extends JFrame{
	protected static String name;
	protected static LayoutManager layout;
	protected static int w, h;
	protected static boolean resizable;
	protected static int clsOpr;
	protected GUI(){
		super(name);
		setLayout(null);
		setSize(w, h);
		setResizable(resizable);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(clsOpr);
		setVisible(true);
	}
}
