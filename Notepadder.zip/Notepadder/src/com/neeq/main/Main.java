package com.neeq.main;

import com.neeq.frames.MainFrame;

public class Main
{
	public static void main(String[] args)
	{
		MainFrame mainFrm = new MainFrame();
	}
}
