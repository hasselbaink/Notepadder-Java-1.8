package com.neeq.design;
/**
 * This class has a Border templates
 * @author hasselbaink
 * @version 1.0
 * @since 1.0
 */
import javax.swing.border.Border;
import javax.swing.BorderFactory;

public class Borders{
	public final Border EMPTY	= BorderFactory.createEmptyBorder();
	public final Border EMPTY1616	= BorderFactory.createEmptyBorder(1, 6, 1, 6);
	public final Border EMPTY6666	= BorderFactory.createEmptyBorder(6, 6, 6, 6);
}
