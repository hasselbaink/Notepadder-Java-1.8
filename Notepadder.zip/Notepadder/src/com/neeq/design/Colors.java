package com.neeq.design;
/**
 * This class has a Color templates
 * @author hasselbaink
 * @version 1.0
 * @since 1.0
 */
import java.awt.Color;

public class Colors{
	public final Color WHITE	= Color.WHITE;
	public final Color BLACK	= Color.BLACK;
	public final Color GRAY		= Color.GRAY;
	public final Color LIGHT_GRAY	= Color.LIGHT_GRAY;
	public final Color DARK_GRAY	= Color.DARK_GRAY;
	public final Color CYAN		= Color.CYAN;
	
	public final Color C70		= new Color(70, 70, 70);
	public final Color C80		= new Color(80, 80, 80);
	public final Color C90		= new Color(90, 90, 90);
	public final Color C100		= new Color(100, 100, 100);
	public final Color C110		= new Color(110, 110, 110);
	public final Color C120		= new Color(120, 120, 120);
	
	public final Color C210		= new Color(210, 210, 210);
	public final Color C220		= new Color(220, 220, 220);
	public final Color C230		= new Color(230, 230, 230);
	public final Color C240		= new Color(240, 240, 240);
	public final Color C250		= new Color(250, 250, 250);
}
