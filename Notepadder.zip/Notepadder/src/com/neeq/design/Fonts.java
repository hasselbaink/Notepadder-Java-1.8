package com.neeq.design;
/**
 * This class has a Font templates
 * @author hasselbaink
 * @version 1.0
 * @since 1.0
 */
import java.awt.Font;

public class Fonts{
	public final Font COLIBRI12	= new Font("Colibri", 0, 12);
	public final Font COLIBRI16	= new Font("Colibri", 0, 16);
	public final Font COLIBRI20	= new Font("Colibri", 0, 20);
	public final Font COLIBRI25	= new Font("Colibri", 0, 25);
	public final Font COLIBRI30	= new Font("Colibri", 0, 30);
	
	public final Font COLIBRI16BOLD	= new Font("Colibri", Font.BOLD, 16);
}
