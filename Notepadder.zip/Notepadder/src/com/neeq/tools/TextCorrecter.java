package com.neeq.tools;
/**
 * This class correct text in the right order.
 * @author hasselbaink
 * @version 1.0
 * @since 1.0
 */
import java.util.ArrayList;

public class TextCorrecter{
	/**
	 * This method remove file type from file name.
	 * @param String File name with type.
	 * @param String[] File types.
	 * @return String Return file name, which went removed from file type.
	 */
	public String correctFileName(String fileName, String[] type){
		StringBuilder result = new StringBuilder();
		char[] c = fileName.toCharArray();
		for(int i = 0; i < c.length; i++){
			if(c[i] == '.'){
				boolean ended = true;
				for(int j = 0; j < type.length; j++){
					if(fileName.substring(i) == type[j] 
							&& fileName.substring(i).length() == type[j].length()) break;
				}
				if(ended) break;
			}else result.append(c[i]);
		}
		return result.toString();
	}
	/**
	 * This method write files names from usual String to String[] array.
	 * @param String Files names, which we want get separately
	 * @return String[] Separaely files names.
	 */
	public String[] correctRecentFilesNames(String filesNames){
		ArrayList<String> list = new ArrayList<String>();
		char[] c = filesNames.toCharArray();
		StringBuilder fileName = new StringBuilder();
		for(int i = 0; i < c.length; i++){
			if(c[i] == ';')
			{
				list.add(fileName.toString());
				fileName = new StringBuilder();
			}else fileName.append(c[i]);
		}
		String[] result = new String[list.size()];
		for(int i = 0; i < result.length; i++){
			result[i] = list.get(i);
		}
		return result;
	}
	/*public String correctHTML(String text){
		StringBuilder result = new StringBuilder();
		char[] c = text.toCharArray();
		for(int i = 0; i < c.length; i++){
			if(c[i] == '>')
				result.append(c[i] + "\n");
			else result.append(c[i]);
		}
		return result.toString();
	}*/
}
