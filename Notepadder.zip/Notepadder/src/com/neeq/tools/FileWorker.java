package com.neeq.tools;
/**
 * This class work with files
 * @author hasselbaink
 * @version 1.0
 * @since 1.0
 */
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Formatter;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;

public class FileWorker
{
	public static String[] fileTypesString = {".html", ".css", ".js"};
	
	private Scanner scn;
	private Formatter frm;
	private BufferedReader reader;
	private File path;
	private String fileName;
	
	public FileWorker(File path)
	{
		this.path = path;
	}
	public FileWorker(String path)
	{
		this.path = new File(path);
	}
	public FileWorker(File absPath, File fileName)
	{
		this.path = new File(absPath + "//" + fileName);
	}
	public FileWorker(String absPath, String fileName)
	{
		this.path = new File(absPath + "//" + fileName);
	}
	/** This method create file */
	public void createFile()
	{
		new File(path.getParent()).mkdirs();
		try{
			frm = new Formatter(path);
			frm.format("");
			frm.close();
		}catch(Exception ex){
			System.out.println("Error: Creating File");
			System.out.println(path);
		}
	}
	/** 
	 * This method save file
	 * @param String Text, which we want save in our file.
	 */
	public void saveFile(String text)
	{
		try{
			frm = new Formatter(path);
			frm.format(text);
			frm.close();
		}catch(Exception ex){
			System.out.println("Error: Saving File");
			System.out.println(path);
		}
	}
	/** 
	 * This method create file.
	 * @return String Return text, which this method readed in file
	 */
	public String readFile()
	{
		try{
			StringBuilder text = new StringBuilder();
			ArrayList<String> list = new ArrayList<String>();
			reader = new BufferedReader(new FileReader(path));
			String line = reader.readLine();
			while(line != null)
			{
				list.add(line);
				line = reader.readLine();
			}
			for(int i = 0; i < list.size(); i++)
				text.append(list.get(i) + "\n");
			return text.toString();
		}catch(Exception ex){
			System.out.println("Error: Reading File");
			System.out.println(path);
			return null;
		}
	}
	/** 
	 * This method check creating file.
	 * @return boolean If file created then return true else false. 
	 */
	public boolean hasFile()
	{
		try{
			if(new File(path.getParent()).listFiles().length != 0)
			{
				File[] list = new File(path.getParent()).listFiles();
				for(int i = 0; i < list.length; i++)
					if(path.getName() == list[i].toString())
						return true;
				return false;
			}
			else return false;
		}catch(Exception ex){return false;}
	}
	/**
	 * This method return path.
	 * @return File path, which we set.
	 */
	public File getPath()
	{
		return path;
	}
}
